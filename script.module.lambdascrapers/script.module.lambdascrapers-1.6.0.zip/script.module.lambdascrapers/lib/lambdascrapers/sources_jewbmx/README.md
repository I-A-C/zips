# ScraperHub

Exodus based eng scrapers collection. 

*Note: Will add more as they get a fix.*

Everything inside here is NOT meant for public use!

This is all for an ongoing project in the LambdaScrapers.

Any misuseage of these files could cause you to get in trouble with BigGov!
